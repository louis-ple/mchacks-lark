import java.util.Scanner;
import java.util.Arrays;
public class Seating_app{
  
  
  public static void main (String []args){
    Scanner read = new Scanner(System.in);
    
    System.out.println("Welcome to the app. Would you like to create a Restaurant Profile? (true/false)");
    boolean create_or_keep =  Boolean.valueOf(read.nextLine());
    if(create_or_keep){
      System.out.println("Please enter your restaurant name: ");
      String res_name = read.nextLine();
      System.out.println("Please enter your restaurant password (we don't care about conditions): ");
      String password = read.nextLine();
      System.out.println("Please enter your amount of tables. This will be used on the next step: ");
      int num_tables = Integer.parseInt(read.nextLine());
      System.out.println("Please enter your amount of servers. This will be used for the next stage: ");
      int num_servers = Integer.parseInt(read.nextLine());
      Restaurants r1 = new Restaurants(res_name, password, num_tables, num_servers);
      System.out.println("Do you wish to preceed to seating, or to quit (true/false)? ");
      create_or_keep = Boolean.valueOf(read.nextLine());
      while(create_or_keep){
       r1.seating();
       
       System.out.println("Seat another? (true/false)");
       create_or_keep = Boolean.valueOf(read.nextLine());
      }
    }
    if(create_or_keep){
      System.out.println("Sick Puppies");
      //go to seating after seeing the profiles
    } else {
      System.out.println("Thank you, come again.");
    }
  }
  
}