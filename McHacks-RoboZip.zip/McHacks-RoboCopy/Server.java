public class Server{
  private String name;
  private int[] table_arr;
  public int table_cap;
  private int tables_serving;
  
  public Server(String s_name, int s_cap){
    this.name = s_name;
    this.table_arr = new int[s_cap];
    this.table_cap = s_cap;
    this.tables_serving = 0;
  }
  
  public Boolean addTable(int t_num){
    boolean added = false;
    for(int i = 0; i<this.table_cap; i++){
      if (this.table_arr[i] == 0){
        this.table_arr[i] = t_num;
        added = true;
        i = (this.table_cap + 1);
      }
    }
    return added;
  }
    
  
  public void print_s(){
    System.out.println("Server Name: " + this.name);
    System.out.println("Tables serving: ");
    for(int i = 0; i<this.table_cap; i++){
     System.out.print(this.table_arr[i] + " ");
    }
    System.out.println("");
  }
   
  
  public static void main (String[] args){
   Server s1 = new Server("Mary", 5);
   System.out.println(s1.name);
   System.out.println(s1.table_arr[0]);
   s1.addTable(33);
   s1.addTable(32);
   s1.addTable(30);
   s1.addTable(38);
   s1.addTable(36);
   s1.addTable(43);
   s1.print_s();
  }
}