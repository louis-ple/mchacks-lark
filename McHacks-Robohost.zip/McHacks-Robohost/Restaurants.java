import java.util.Scanner;
import java.util.Arrays;
public class Restaurants{
  private int numTables;
  private int numServers;
  private Table[] tables;
  private Server[] servers;
  private String name;
  private String password;
  private int serving_cap;
  
  
  public Restaurants(String r_name, String r_pword, int r_tables, int r_servers){
    this.name = r_name;
    this.password = r_pword;
    this.numTables = r_tables;
    this.servers = new Server[r_servers];
    this.numServers = r_servers;
    this.tables = create_tables(r_tables);
    this.servers = create_servers(r_servers);
    this.serving_cap = calculate_cap(this.servers);
    printResto();
  }
  
  private Table[] create_tables(int nums){
    Scanner read = new Scanner(System.in);
    System.out.println("Welcome to the table population process.");
    System.out.println("You will proceed to enter the parameters of all your tables.");
    Table[] R_tables = new Table[nums];
    for (int j = 0 ; j < nums; j++){
      System.out.println("Table #" + j + ". Table number is: (integer)");
      int table_num = Integer.parseInt(read.nextLine());
      System.out.println("The number of seats is: (integer)");
      int num_seats = Integer.parseInt(read.nextLine());
      System.out.println("Is this table in a smoking section (boolean)? ");
      boolean b_smoke = Boolean.valueOf(read.nextLine());
      System.out.println("Please enter the area of the restaurant where the table is located.");
      String t_section = read.nextLine();
      System.out.println("Please enter the proximity of the table to a tv screen (range of 0,1,2, 2 is closest).");
      int t_tv = Integer.parseInt(read.nextLine());
      System.out.println("Please enter the proximity of the table to a beautiful window vista (range 0,1,2, 2 is closest).");
      int t_windows = Integer.parseInt(read.nextLine());
      System.out.println("Please enter the proximity of the table to the bathrooms (range 0,1,2, 2 is closest).");
      int t_bath = Integer.parseInt(read.nextLine());
      System.out.println("Please enter the proximity of the table to the kitchen (range 0,1,2, 2 is closest).");
      int t_kitchen = Integer.parseInt(read.nextLine());
      System.out.println("Lastly, please enter the handicapped accessibility of the table (same range as above, 2 is most accessible).");
      int t_access = Integer.parseInt(read.nextLine());
      R_tables[j] = new Table(table_num, num_seats, b_smoke, t_section, t_tv, t_windows, t_bath, t_kitchen, t_access);
      System.out.println("Table Created.");
    }
    return R_tables;
  }
  
  private void printResto(){
   System.out.println("The details of your fine establishment: ");
   System.out.println("Your name: " + this.name);
   System.out.println("Your password: " + this.password);
   System.out.println("Your tables: ");
   printTables(this.tables);
   System.out.print("Now your servers: ");
   printServers(this.servers);  
   System.out.println("You can serve " + this.serving_cap + " tables.");
  }
  
  private void printTables(Table[] tables){
    for(int i = 0; i<tables.length; i++){
     System.out.print((i + 1) + "th table: ");
     tables[i].PrintTable(); 
    }
  }
  
  private void printServers(Server[] servers){
    for(int i = 0; i<servers.length; i++){
     servers[i].print_s(); 
    }
  }
  
  private Server[] create_servers(int nums){
    Scanner read = new Scanner(System.in);
    Server[] R_servers = new Server[nums];
    System.out.println("Welcome to the server population process.");
    System.out.println("You will proceed to enter the parameters of all of your servers.");
    for(int i = 0; i<nums; i++){
      System.out.println("Enter your Server's name: ");
      String s_name = read.nextLine();
      System.out.println("Enter the amount of tables she can handle: ");
      int s_tcap = Integer.parseInt(read.nextLine());
      R_servers[i] = new Server(s_name, s_tcap);
    }
    System.out.println("Servers added.");
    return R_servers;
  }
  
  public int calculate_cap(Server[] servers){
    int total_cap = 0;
    for(int i = 0; i<servers.length; i++){
      total_cap = total_cap + servers[i].get_table_cap();
    }
    return total_cap; 
  }
  
  public void seating(){
   
   Table[] avail_tables = this.tables;
   Scanner read = new Scanner(System.in);
   boolean req = false;
   boolean smoke_touch = false;
   boolean section_touch = false;
   boolean tv_touch = false;
   boolean bath_touch = false;
   boolean kitchen_touch = false;
   boolean access_touch = false;
   int numWanted = -1;
   
   
   //plan: iterate through all of the "necessary categories" If user writes true, go into nec.pi.that.category.
   //will print the available tables, and to enter his requirements. Then iterate through "available tables", and keep those who fit. If none do, tell him he is a lose and exit.
   //at end, print the "intermediate list". Allow user to select from the intermediate list.
   avail_tables = Table.cull_first(avail_tables);
   System.out.println("Your available tables: ");
   printTables(avail_tables);
   
   System.out.println("We will iterate through all of the categories that the client may find necessary. It the category presented is one such, say true.");
   System.out.println("You will then be prompted to enter the user's wishes for that category, and a list of fitting tables will be outputted.");
   System.out.println("But first, enter the amount of seats requested.");
   
   int seats_req = Integer.parseInt(read.nextLine()); 
   avail_tables = Table.cull_tables(avail_tables, (seats_req/2));
   if(avail_tables.length == 0){
     System.out.println("Too restrictive, no tables available.");
     return;
   }
   System.out.println("Available Tables: ");
   printTables(avail_tables);
   
   System.out.println("Is a smoking/non-smoking area a necessity?");
   boolean smoke_req = Boolean.valueOf(read.nextLine());
   smoke_touch = smoke_req;
   if(smoke_req){
     System.out.println("Smoking/Non-Smoking? (true/false)");
     smoke_req = Boolean.valueOf(read.nextLine()); 
     avail_tables = Table.cull_smoke(avail_tables, smoke_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a certain seating section necessary");
   req = Boolean.valueOf(read.nextLine());
   section_touch = req;
   if(req){
     System.out.println("Enter the necessary seating section.");
     String section = read.nextLine();
     avail_tables = Table.cull_section(avail_tables, section);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a certain proximity to a TV screen absolutely necessary?");
   req = Boolean.valueOf(read.nextLine());
   tv_touch = req;
   if(req){
     System.out.println("Enter the proximity to the TV required (0 furthest, 2 closest).");
     int TV_req = Integer.parseInt(read.nextLine()); 
     avail_tables = Table.cull_TV(avail_tables, TV_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a certain proximity to a bathroom absolutely necessary?");
   req = Boolean.valueOf(read.nextLine());
   bath_touch = req;
   if(req){
     System.out.println("Enter the proximity to the restroom required (0 furthest, 2 closest).");
     int dist_req = Integer.parseInt(read.nextLine()); 
     avail_tables = Table.cull_Bath(avail_tables, dist_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a certain proximity to a window absolutely necessary?");
   req = Boolean.valueOf(read.nextLine());
   boolean window_touch = req;
   if(req){
     System.out.println("Enter the proximity to the window vista required (0 furthest, 2 closest).");
     int dist_req = Integer.parseInt(read.nextLine()); 
     avail_tables = Table.cull_Window(avail_tables, dist_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a certain proximity to a kitchen absolutely necessary?");
   req = Boolean.valueOf(read.nextLine());
   kitchen_touch = req;
   if(req){
     System.out.println("Enter the proximity to the kitchen required (0 furthest, 2 closest).");
     int dist_req = Integer.parseInt(read.nextLine()); 
     avail_tables = Table.cull_Kitch(avail_tables, dist_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
     System.out.println("Available Tables: ");
     printTables(avail_tables);
   }
   
   System.out.println("Is a handicapped accessible table absolutely necessary?");
   req = Boolean.valueOf(read.nextLine());
   access_touch = req;
   if(req){
     System.out.println("Enter the accessibility required (0 furthest, 2 closest).");
     int dist_req = Integer.parseInt(read.nextLine()); 
     avail_tables = Table.cull_access(avail_tables, dist_req);
     if(avail_tables.length == 0){
       System.out.println("Too restrictive, no tables available.");
       return;
     }
   }
   
   System.out.println("Here are the available tables remaining.");
   printTables(avail_tables);
   System.out.println("Would you like to make a selection now, or proceed to the priorities stage? (true/false)");
   req = Boolean.valueOf(read.nextLine());
   if (req) {
    System.out.println("Please make your selection."); 
    numWanted = Integer.parseInt(read.nextLine());
   }
    else {
      numWanted = Table.softSelect(avail_tables, !smoke_touch, !section_touch, !tv_touch, !bath_touch, !kitchen_touch, !window_touch, !access_touch); 
      //IE now true will mean has not been touched.
   }
   for(int i = 0; i<avail_tables.length;i++){
     if (avail_tables[i].getNumFree() == numWanted){
       Table.setInUse(avail_tables[i]);
       i = avail_tables.length; 
     }
   }
   int s = find_best_server(this.servers, numWanted);
   System.out.println("Table " + numWanted + " has been selected and assigned to " + servers[s].get_server_name() + ". Thank you.");
   this.serving_cap = calculate_cap(this.servers);
   printResto();
   return;
  }
  
  private static int find_best_server(Server[] s, int n_to_add){
    Server s_best = s[0];
    int i = 0;
    for(i=0; i<s.length; i++) {
      if(s_best.get_table_cap() < s[i].get_table_cap()){
        s_best = s[i];
      }
    }
    s_best.addTable(n_to_add);
    return i;
  }
    
  public static void main (String []args){
   System.out.println("Beefsteaks"); 
  }
}
  
  