import java.util.Scanner;
import java.util.*;
public class Table{
  private int NumPlaces;
  private boolean Smoking;
  private String section;
  private int TV_Prox;
  private int Window_Prox;
  private int Bath_Prox;
  private int Kitch_Prox;
  private int accessibility;
  private boolean in_use;
  private int table_num;
  
  public Table(int num, int Seats, boolean Smoke, String section, int tv, int window, int bath, int kitch, int access){
    this.NumPlaces = Seats;
    this.Smoking = Smoke;
    this.section = section;
    this.TV_Prox = tv;
    this.Window_Prox = window;
    this.Bath_Prox = bath;
    this.Kitch_Prox = kitch;
    this.accessibility = access;
    this.in_use = false;
    this.table_num = num;
  }
  
  public void PrintTable(){
    System.out.println("Table # " + this.table_num + ". Number of Seats: " + this.NumPlaces + ". Smoking area: " +  this.Smoking + ". Seating area: " + this.section);
    System.out.println("TV proximity: "  + this.TV_Prox + ". Window Proximity " + this.Window_Prox + ". Bathroom proximity: " + this.Bath_Prox);
    System.out.println("Kitchen proximity: " + this.Kitch_Prox + ". mobile accessibility " + this.accessibility);
    System.out.println("In use: " + this.in_use);
  }
  
  public static void setInUse(Table t_x){
    t_x.in_use = true;
  }
  
  
  public int getNumFree(){
    if(this.in_use){
      return -1;
    } else {
      return this.table_num;
    }
  }
  
  public static Table[] cull_tables(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].NumPlaces >= num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].NumPlaces >= num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
  public static Table[] cull_smoke(Table[] in, boolean smokes){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].Smoking == smokes){
        f_i++;
      }
    }
    int n_added = 0;
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].Smoking == smokes){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
   public static Table[] cull_TV(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].TV_Prox == num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    System.out.println(f_i);
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].TV_Prox == num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
  public static Table[] cull_Window(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].Window_Prox == num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    System.out.println(f_i);
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].Window_Prox == num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
   public static Table[] cull_Bath(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].Bath_Prox == num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    System.out.println(f_i);
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].Bath_Prox == num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
   
    public static Table[] cull_Kitch(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].Kitch_Prox == num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    System.out.println(f_i);
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].Kitch_Prox == num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
    
     public static Table[] cull_access(Table[] in, int num_needed){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(in[i].accessibility == num_needed){
        f_i++;
      }
    }
    int n_added = 0;
    System.out.println(f_i);
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(in[i].accessibility == num_needed){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
  public static Table[] cull_section(Table[] in, String section_string){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(section_string.equalsIgnoreCase(in[i].section)){
        f_i++;
      }
    }
    int n_added = 0;
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(section_string.equalsIgnoreCase(in[i].section)){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
  public static Table[] cull_first(Table[] in){
    int f_i = 0;//first iterating
    for(int i = 0; i<in.length; i++){
      if(!(in[i].in_use)){
        f_i++;
      }
    }
    int n_added = 0;
    Table[] meetReq = new Table[f_i];
    for(int i = 0; i<in.length; i++){
      if(!(in[i].in_use)){
        meetReq[n_added] = in[i];
        n_added++;
      }
    }
    return meetReq;
  }
  
  public static int softSelect(Table[] tables, boolean smoke, boolean sect, boolean tv, boolean window, boolean bath, boolean kitchen, boolean access){
   Scanner read = new Scanner(System.in);
   int n_picked = 0; 
   int[] get_maxed = new int[tables.length];
   boolean s_pref = false;
   String sec_pref = "";
   int tv_pref = -1;
   int win_pref = -1;
   int bath_pref = -1;
   int kitch_pref = -1;
   int acc_pref = -1;
   if(smoke){
    System.out.println("Please enter whether smoking/non-smoking is preferred (true/false)");
    s_pref = Boolean.valueOf(read.nextLine());
   }
   if(sect){
     System.out.println("Please enter the preferred section for seating.");
     sec_pref = read.nextLine();
   }
   if(tv){
    System.out.println("Please enter the preferred level of TV sightlines (again 2 is closest).");
    tv_pref = Integer.parseInt(read.nextLine());
   }
   if(window){
    System.out.println("Please enter the preferred level of window proximity (2 closest).");
    win_pref = Integer.parseInt(read.nextLine());
   }
   if(bath){
    System.out.println("Please enter the preferred level of bathroom proximity (2 closest).");
    bath_pref = Integer.parseInt(read.nextLine()); 
   }
   if(kitchen){
    System.out.println("Please enter the preferred level of kitchen proximity (2 closest).");
    kitch_pref = Integer.parseInt(read.nextLine());
   }
   if(access){
     System.out.println("Please enter the preferred level of mobility access (2 closest).");
     acc_pref = Integer.parseInt(read.nextLine());
   }
   for(int i=0; i<tables.length;i++){
    int r_total = 0;
    if(smoke) {
      if(s_pref == tables[i].Smoking){
       r_total = r_total + 5;
      }
    }
    if(sect){
      if(sec_pref.equals(tables[i].section)){
       r_total = r_total + 5;
      }
    }
    if(tv){
      r_total = add(tables[i].TV_Prox, tv_pref);
    }
    if(window){
      r_total = add(tables[i].Window_Prox, win_pref);
    }
    if(bath){
     r_total = add(tables[i].Bath_Prox, bath_pref); 
    }
    if(kitchen){
      r_total = add(tables[i].Kitch_Prox, kitch_pref) + r_total;
    }
    if(access){
      r_total = add(tables[i].accessibility, acc_pref) + r_total;
    }
    get_maxed[i] = r_total;
   }
   n_picked = 0;
   for(int j=0; j<get_maxed.length; j++) {
     if(get_maxed[j]>get_maxed[n_picked]){
       n_picked = get_maxed[j];
     }
   }
   return tables[n_picked].table_num;
  }
  
  private static int add(int t_val, int t_pref){
    if(t_val == t_pref){
      return 5;
    } else if((t_val-1) == t_pref || (t_val + 1) == t_pref){
      return 2;
    } 
    return 0;
  }
    
  public static void main (String []args){
    Table t1 = new Table(2, 4, true, "floor_1", 2, 2, 1, 1, 3);
    t1.PrintTable();
    System.out.println("Hello");
  }
}